
let cart = Number(localStorage.getItem("amyaeCart") || 0);
function updateCart(){document.querySelectorAll(".cartCount").forEach(x=>x.textContent=cart);localStorage.setItem("amyaeCart",cart);}
function addToCart(){cart++;updateCart();alert("Product added to your cart.");}
function buyNow(){addToCart();window.location.href="checkout.html";}
document.addEventListener("DOMContentLoaded",updateCart);
